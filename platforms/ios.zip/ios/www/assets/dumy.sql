CREATE TABLE IF NOT EXISTS user(id INTEGER PRIMARY KEY AUTOINCREMENT, fp_id INTEGER, user_id INTEGER,auth_token_tw TEXT , oauth_token_secret_tw TEXT , user_id_soc_tw TEXT );
